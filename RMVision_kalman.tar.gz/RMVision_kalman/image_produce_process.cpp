#include "image_produce_process.h"
#include "serial.h"
#include "serial_port.h"
#include "kalman.hpp"

#include<iostream>
#include<fstream>

struct ImageData
{
    Mat img;
    //    unsigned int frame;
};
//设置结束线程标志位，负责结束所有线程。
static volatile bool end_thread_flag  = false;
static volatile unsigned int prdIdx;
static volatile unsigned int csmIdx;

static volatile unsigned int gimbal_data_index;
static volatile unsigned int consumption_index;

static volatile bool cap_mode_ = 0;
//static vector<float> vec_gimbal_yaw;
static float vec_gimbal_yaw;
static ImageData data[BUFFER_SIZE];



ImageProduceProcess::ImageProduceProcess()
{
    cout <<"Open the thread of ImageDate" << endl;
//    SerialPort serial("/dev/ttyUSB0",0);
//    serial_ = serial;

}

// 图像生成线程
void ImageProduceProcess::ImageProduce()
{

    CaptureVideo camera("/dev/video0", 3);                // 选择相机驱动文件，可在终端下输入"ls /dev" 查看. 4帧缓存
    camera.setVideoFormat(VIDEO_WIDTH, VIDEO_HEIGHT, 1);   // 设置长宽格式及使用mjpg编码格式
    camera.setExposureTime(0, 10);                         // 手动曝光，设置曝光时间。
    camera.startStream();                                  // 打开视频流
    camera.info();                                         // 输出摄像头信息
    while(1)
    {
        while(prdIdx - csmIdx >= BUFFER_SIZE)
            END_THREAD;
        camera >> data[prdIdx % BUFFER_SIZE].img;
        ++prdIdx;
        END_THREAD;

    }
}


int ct = 0;
double sum0 = 0;
// 图像处理线程
void ImageProduceProcess::ImageProcess()
{
    Param_ para_armor, para_buff;
    namedWindow("control");
    createTrackbar("gray_th", "control", &para_armor.gray_th, 255);
    createTrackbar("color_th", "control", &para_armor.color_th, 255);
    cv::createTrackbar("offset_x","control",&para_armor.offset_x,200);
    cv::createTrackbar("offset_y","control",&para_armor.offset_y,200);

    Mat image;
    float angle_x = 0.0, angle_y = 0.0, distance = 0.0, theta_y = 0.0;
    SolveAngle solve_angle("/home/coscj/projects/guangong_test/camera.xml", -0, -42.5, -135, 0);
    int fd2car = openPort("/dev/ttyUSB0");
    configurePort(fd2car);
    int i=0;
    double start0,finish0,time0;


    //kalman滤波器
    KalmanFilterAngle kf(0, 0);//Differ from cv::KalmanFilter

    Point2f currentPoint(0,0);
    Mat kalmanPoint;

    int countfile = 0;
    ofstream fout("yaw.txt");
    ofstream foutk("kal.txt");
    float orig_x;

    while(1)
    {

        //跑整张图的时间 = 获取图像 + 处理图像 = 3ms
        //只要保证处理图像的时间在获取图像的时间的一半左右，那就使得总时间=获取图像的时间
        while(prdIdx - csmIdx == 0);
        data[csmIdx % BUFFER_SIZE].img.copyTo(image);
        ++csmIdx;


        ct++;
        start0 = getTickCount();

        time0 = ( start0 - finish0)/getTickFrequency()*1000;
        cout<<time0<<endl;

        finish0 = getTickCount();

        if(ct!=1)
        {
            sum0 += time0;
            cout<<"平均使用时间  "<<sum0/ct<<endl;
        }


        //装甲板检测这块需要的时间还是0.9ms
        bool find_flag = ArmorDetectTask(image, para_armor);   // 装甲板检测
        if(find_flag)
        {
            solve_angle.Generate3DPoints(0, Point2f());
            solve_angle.getAngle(para_armor.points_2d, 14,angle_x,angle_y,distance,theta_y);            // pnp姿态结算

          //  while(static_cast<int>(gimbal_data_index - consumption_index) == 0);
           //     consumption_index++;


            kalmanPoint = kf.run(angle_x + vec_gimbal_yaw,angle_y);

            orig_x = angle_x;
            angle_x = kalmanPoint.at<float>(0) - vec_gimbal_yaw;


        }
        else
        {
            cout<<i++<<endl;
            angle_x = 0;
            angle_y = 0;
            distance = 0;
            orig_x = 0;
        }
        limit_angle(angle_x, 4);


        foutk<<countfile<<" "<<angle_x*100<<" "<<orig_x*100<<"\n";
        countfile++;

//        tx_data.get_xy_data(static_cast<int16_t>(angle_x*100), static_cast<int16_t>(angle_y*100), static_cast<int16_t>(distance*100));
//        serial_.send_data(tx_data);
        double send_data[4] = {0};
        send_data[0] = angle_x*100;
        send_data[1] = -angle_y*50;
//        send_data[2] = 0;
//        send_data[3] = 0;
        sendXYZ(fd2car, send_data);
       imshow("image",image);
       if(waitKey(1)>0)
            end_thread_flag = true;

        END_THREAD;
    }
}



void limit_angle(float &a, float max)
{
    if(a > max)
        a = max;
    else if(a < -max)
        a = -max;
}
