
#include <opencv2/opencv.hpp>
#include "image_produce_process.h"
#include <thread>

#include <unistd.h>
using namespace std;
using namespace cv;


//
int adjustExposure(){
    CaptureVideo cap("/dev/video0", 3);
    cap.setVideoFormat(640, 360, 1);
    int exp_t = 10;
    cap.setExposureTime(0, exp_t);//settings->exposure_time);
    cap.startStream();
    cap.info();
    int ct=0;
    double sum0 = 0;
    double t,start,finish;

    //跑一张空图需要的时间大概在3ms左右
    while(1){
        Mat src;

         start = getTickCount();
        cap >> src;
         finish = getTickCount();

         t = (finish - start)/getTickFrequency() *1000;
        ct++;
        sum0 += t;
        cout<<"平均使用时间  "<<sum0/ct<<"平均帧率:  "<<1/(sum0/ct)*1000<<endl;
        cout<<"时间是:"<<t<<"      "<<1.0/t*1000<<endl;
       // imshow("src", src);

      //  char key = waitKey(1);
//        if (key == 'w'){
//            exp_t += 1;
//            cap.setExposureTime(0, exp_t);//settings->exposure_time);
//            cout << "current exp t:\t" << exp_t << endl;
//        }
//        else if(key == 's'){
//            exp_t -= 1;
//            cap.setExposureTime(0, exp_t);
//            cout << "current exp t:\t" << exp_t << endl;
//        }
    }
}

int main()
{
  //adjustExposure();
  ImageProduceProcess ImageControl;
  std::thread produce_task(&ImageProduceProcess::ImageProduce, ImageControl);
  std::thread process_task(&ImageProduceProcess::ImageProcess, ImageControl);

  produce_task.join();
  process_task.join();
    return 1;
}

